﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Device.Location;
using Microsoft.Phone.Tasks;

namespace Day13_LocationServices
{
	public partial class MainPage : PhoneApplicationPage
	{
		GeoCoordinateWatcher gcw;
		
		// Constructor
		public MainPage()
		{
			InitializeComponent();
		}

		void gcw_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
		{
			Latitude.Text = e.Position.Location.Latitude.ToString();
			Longitude.Text = e.Position.Location.Longitude.ToString();
			Accuracy.Text = e.Position.Location.HorizontalAccuracy.ToString();
			MapButton.IsEnabled = true;
		}

		void gcw_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
		{
			Status.Text = e.Status.ToString();
		}

		private void StartButton_Click(object sender, RoutedEventArgs e)
		{
			if (HighBox.IsChecked == true)
				gcw = new GeoCoordinateWatcher(GeoPositionAccuracy.High);
			else
				gcw = new GeoCoordinateWatcher(GeoPositionAccuracy.Default);

			gcw.StatusChanged += new EventHandler<GeoPositionStatusChangedEventArgs>(gcw_StatusChanged);
			gcw.PositionChanged += new EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(gcw_PositionChanged);
			gcw.Start();

			StartButton.IsEnabled = false;
			StopButton.IsEnabled = true;
		}

		private void StopButton_Click(object sender, RoutedEventArgs e)
		{
			if (gcw != null) gcw.Stop();

			StartButton.IsEnabled = true;
			StopButton.IsEnabled = false;

			Latitude.Text = "";
			Longitude.Text = "";
			Status.Text = "Stopped";
		}

		private void MapButton_Click(object sender, RoutedEventArgs e)
		{
			Map.Visibility = Visibility.Visible;
			Map.Center = new GeoCoordinate(gcw.Position.Location.Latitude, gcw.Position.Location.Longitude);
			Map.ZoomLevel = 17;
			Map.ZoomBarVisibility = Visibility.Visible;
			Map.ScaleVisibility = Visibility.Visible;
		}
	}
}