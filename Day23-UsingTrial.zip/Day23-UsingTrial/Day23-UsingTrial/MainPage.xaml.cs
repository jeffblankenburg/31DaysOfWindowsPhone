﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Marketplace;
using System.IO.IsolatedStorage;

namespace Day23_UsingTrial
{
	public partial class MainPage : PhoneApplicationPage
	{
		LicenseInformation li = new LicenseInformation();
		IsolatedStorageSettings settings = IsolatedStorageSettings.ApplicationSettings;
		
		// Constructor
		public MainPage()
		{
			InitializeComponent();

			if (!li.IsTrial()||(bool)settings["trialMode"] == false)
			{
				//Do something that only paid users can do.
			}
			else if (li.IsTrial() || (bool)settings["trialMode"] == true)
			{
				//Do something that all users, trial or paid, can do.
			}
		}
	}
}