﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;
using System.Windows.Media.Imaging;

namespace Day8_Choosers
{
	public partial class MainPage : PhoneApplicationPage
	{
		// Constructor
		public MainPage()
		{
			InitializeComponent();
		}

		private void GetEmailButton_Click(object sender, RoutedEventArgs e)
		{
			EmailAddressChooserTask eact = new EmailAddressChooserTask();
			eact.Completed += new EventHandler<EmailResult>(eact_Completed);
			eact.Show();
		}

		void eact_Completed(object sender, EmailResult e)
		{
			EmailBlock.Text = e.Email;
		}

		private void CaptureCameraButton_Click(object sender, RoutedEventArgs e)
		{
			CameraCaptureTask cct = new CameraCaptureTask();
			cct.Completed += new EventHandler<PhotoResult>(cct_Completed);
			cct.Show();
		}

		void cct_Completed(object sender, PhotoResult e)
		{
			BitmapImage bmp = new BitmapImage();
			bmp.SetSource(e.ChosenPhoto);
			image1.Source = bmp;
		}

		private void GetPhoneNumberButton_Click(object sender, RoutedEventArgs e)
		{
			PhoneNumberChooserTask pnct = new PhoneNumberChooserTask();
			pnct.Completed += new EventHandler<PhoneNumberResult>(pnct_Completed);
			pnct.Show();
		}

		void pnct_Completed(object sender, PhoneNumberResult e)
		{
			PhoneBlock.Text = e.PhoneNumber;
		}

		private void GetPhotoButton_Click(object sender, RoutedEventArgs e)
		{
			PhotoChooserTask pct = new PhotoChooserTask();
			pct.Completed += new EventHandler<PhotoResult>(pct_Completed);
			pct.Show();
		}

		void pct_Completed(object sender, PhotoResult e)
		{
			BitmapImage bmp = new BitmapImage();
			bmp.SetSource(e.ChosenPhoto);
			image2.Source = bmp;
		}
	}
}