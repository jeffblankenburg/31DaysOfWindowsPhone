﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO.IsolatedStorage;
using System.IO;
using System.Xml.Linq;

namespace Day15_IsolatedStorage
{
	public partial class MainPage : PhoneApplicationPage
	{
		IsolatedStorageSettings settings = IsolatedStorageSettings.ApplicationSettings;
		IsolatedStorageFile file = IsolatedStorageFile.GetUserStoreForApplication();
		
		// Constructor
		public MainPage()
		{
			InitializeComponent();
			InitializeSettings();
		}

		private void InitializeSettings()
		{
			if (settings.Contains("emailFlag"))
			{
				EmailFlag.IsChecked = (bool)settings["emailFlag"];
			}
			else settings.Add("emailFlag", false);
		}

		private void EmailFlag_Unchecked(object sender, RoutedEventArgs e)
		{
			settings["emailFlag"] = false;
		}

		private void EmailFlag_Checked(object sender, RoutedEventArgs e)
		{
			settings["emailFlag"] = true;
		}

		using System.IO.IsolatedStorage;
		using System.IO;

		private void SaveButton_Click(object sender, RoutedEventArgs e)
		{
			//Obtain a virtual store for application
			IsolatedStorageFile fileStorage = IsolatedStorageFile.GetUserStoreForApplication();

			//Create new subdirectory
			fileStorage.CreateDirectory("textFiles");

			//Create a new StreamWriter, to write the file to the specified location.
			StreamWriter fileWriter = new StreamWriter(new IsolatedStorageFileStream("textFiles\\newText.txt", FileMode.OpenOrCreate, fileStorage));
			//Write the contents of our TextBox to the file.
			fileWriter.WriteLine(writeText.Text);
			//Close the StreamWriter.
			fileWriter.Close();
		}

		private void GetButton_Click(object sender, RoutedEventArgs e)
		{
			//Obtain a virtual store for application
			IsolatedStorageFile fileStorage = IsolatedStorageFile.GetUserStoreForApplication();
			//Create a new StreamReader
			StreamReader fileReader = null;

			try
			{
				//Read the file from the specified location.
				fileReader = new StreamReader(new IsolatedStorageFileStream("textFiles\\newText.txt", FileMode.Open, fileStorage));
				//Read the contents of the file (the only line we created).
				string textFile = fileReader.ReadLine();

				//Write the contents of the file to the TextBlock on the page.
				viewText.Text = textFile;
				fileReader.Close();
			}
			catch
			{
				//If they click the view button first, we need to handle the fact that the file hasn't been created yet.
				viewText.Text = "Need to create directory and the file first.";
			}
		}
	}
}