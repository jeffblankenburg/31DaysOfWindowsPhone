﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace Day2_PageNavigation
{
	public partial class MainPage : PhoneApplicationPage
	{
		// Constructor
		public MainPage()
		{
			InitializeComponent();
		}

private void PastaButton_Click(object sender, RoutedEventArgs e)
{
	Button clickedButton = sender as Button;

	switch(clickedButton.Name)
	{
		case "PastaButton":
			NavigationService.Navigate(new Uri("/Pasta.xaml", UriKind.Relative));
			break;
		case "SauceButton":
			NavigationService.Navigate(new Uri("/Sauce.xaml", UriKind.Relative));
			break;
		case "CheeseButton":
			NavigationService.Navigate(new Uri("/Cheese.xaml", UriKind.Relative));
			break;
	}
}
	}
}
