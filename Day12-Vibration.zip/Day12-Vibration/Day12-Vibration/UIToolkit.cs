﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Day12_Vibration
{
	public static class UIToolkit
	{
		public static void setTimeout(int milliseconds, Action action)
		{
			var timer = new ActionTimer
			{
				Interval = new TimeSpan(0, 0, 0, 0, milliseconds),
				Action = action
			};
			timer.Tick += new EventHandler(timer_Tick);
			timer.Start();
		}

		static void timer_Tick(object sender, EventArgs e)
		{
			var t = sender as ActionTimer;
			t.Stop();
			t.Action();
			t.Tick -= timer_Tick;
		}
	}

	public class ActionTimer : System.Windows.Threading.DispatcherTimer
	{
		public Action Action { get; set; }
	}
}
