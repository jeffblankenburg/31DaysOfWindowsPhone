﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Day17_PivotControl
{
	public class BabyName
	{
		public string Name { get; set; }
		public int Gender1 {get; set; }
		public int Gender2 { get; set; }

		public BabyName()
		{
			
		}

		public BabyName(string name, int gender1, int gender2)
		{
			Gender1 = gender1;
			Gender2 = gender2;
			Name = name;
		}
	}
}
