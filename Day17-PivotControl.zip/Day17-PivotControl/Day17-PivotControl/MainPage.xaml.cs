﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace Day17_PivotControl
{
	public partial class MainPage : PhoneApplicationPage
	{
		BabyName[] names = new BabyName[10] {new BabyName("Steve", 1, 0),
											new BabyName("Jennifer", 2, 0),
											new BabyName("Alex", 1, 2),
											new BabyName("Casey", 1, 2),
											new BabyName("Quinn", 1, 2),
											new BabyName("Anthony", 1, 0),
											new BabyName("Sarah", 2, 0),
											new BabyName("Parker", 2, 1),
											new BabyName("Jessica", 2, 0),
											new BabyName("Jeff", 1, 0)};
		
		// Constructor
		public MainPage()
		{
			InitializeComponent();
			boyList.ItemsSource = from n in names
								  where (n.Gender1 == 1 || n.Gender2 == 1)
								  orderby n.Name
								  select new BabyName(n.Name, n.Gender1, n.Gender2);

			girlList.ItemsSource = from n in names
								  where (n.Gender1 == 2 || n.Gender2 == 2)
								  orderby n.Name
								  select new BabyName(n.Name, n.Gender1, n.Gender2);

			allList.ItemsSource = from n in names
								  orderby n.Name
								  select new BabyName(n.Name, n.Gender1, n.Gender2);
		}
	}
}