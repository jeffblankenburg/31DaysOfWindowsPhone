﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Devices.Sensors;

namespace Day11_Accelerometer
{
	public partial class MainPage : PhoneApplicationPage
	{
		Accelerometer acc = new Accelerometer();
		
		// Constructor
		public MainPage()
		{
			InitializeComponent();
			acc.ReadingChanged += new EventHandler<AccelerometerReadingEventArgs>(acc_ReadingChanged);
			acc.Start();
		}

		void acc_ReadingChanged(object sender, AccelerometerReadingEventArgs e)
		{
			Deployment.Current.Dispatcher.BeginInvoke(() => ThreadSafeAccelerometerChanged(e));
		}

		void ThreadSafeAccelerometerChanged(AccelerometerReadingEventArgs e)
		{
			XText.Text = e.X.ToString("0.000");
			YText.Text = e.Y.ToString("0.000");
			ZText.Text = e.Z.ToString("0.000");
		}
	}
}