﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO;
using Microsoft.Xna.Framework;

namespace Day18_WebBrowserControl
{
	public partial class MainPage : PhoneApplicationPage
	{
		// Constructor
		public MainPage()
		{
			InitializeComponent();
			Browser.Navigated += new EventHandler<System.Windows.Navigation.NavigationEventArgs>(Browser_Navigated);
			Browser.Navigating += new EventHandler<NavigatingEventArgs>(Browser_Navigating);
			Browser.ScriptNotify += new EventHandler<NotifyEventArgs>(Browser_ScriptNotify);
		}

		void Browser_ScriptNotify(object sender, NotifyEventArgs e)
		{
			Browser.Navigate(new Uri(e.Value, UriKind.Absolute));
		}

		void Browser_Navigating(object sender, NavigatingEventArgs e)
		{
			ProgBar.Visibility = Visibility.Visible;
		}

		void Browser_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
		{
			ProgBar.Visibility = Visibility.Collapsed;
		}

		private void button1_Click(object sender, RoutedEventArgs e)
		{
			Browser.Navigate(new Uri(Address.Text, UriKind.Absolute));
			Browser.IsScriptEnabled = true;
		}

		private void ScriptButton_Click(object sender, RoutedEventArgs e)
		{
			StreamReader reader = new StreamReader(TitleContainer.OpenStream("html/script.html"));
			Browser.NavigateToString(reader.ReadToEnd());
		}

		private void WP7Button_Click(object sender, RoutedEventArgs e)
		{
			StreamReader reader = new StreamReader(TitleContainer.OpenStream("html/wp7wiki.html"));
			Browser.NavigateToString(reader.ReadToEnd());
		}

		private void URLButton_Click(object sender, RoutedEventArgs e)
		{
			Browser.NavigateToString((string)Browser.InvokeScript("getText", "http://jeffblankenburg.com", "rocks", "awesomely"));
		}
	}
}