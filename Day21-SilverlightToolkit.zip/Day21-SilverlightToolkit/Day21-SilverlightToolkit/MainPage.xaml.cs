﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace Day21_SilverlightToolkit
{
	public partial class MainPage : PhoneApplicationPage
	{
		// Constructor
		public MainPage()
		{
			InitializeComponent();
		}

		private void MenuItem_Click(object sender, RoutedEventArgs e)
		{

		}

		private void DoubleTapped(object sender, GestureEventArgs e)
		{

		}

		private void Tapped(object sender, GestureEventArgs e)
		{

		}

		private void Held(object sender, GestureEventArgs e)
		{

		}

		private void DragStart(object sender, DragStartedGestureEventArgs e)
		{

		}

		private void DragDelta(object sender, DragDeltaGestureEventArgs e)
		{

		}

		private void DragEnd(object sender, DragCompletedGestureEventArgs e)
		{

		}

		private void Flicked(object sender, FlickGestureEventArgs e)
		{

		}

		private void PinchStart(object sender, PinchStartedGestureEventArgs e)
		{

		}

		private void PinchDelta(object sender, PinchGestureEventArgs e)
		{

		}

		private void PinchEnd(object sender, PinchGestureEventArgs e)
		{

		}

		private void Button1_Click(object sender, RoutedEventArgs e)
		{
			Button1.Width = Button1.Width - 5;
			Button2.Width = Button2.Width - 5;
			Button3.Width = Button3.Width - 5;
			Button4.Width = Button4.Width - 5;
			Button5.Width = Button5.Width - 5;
			Button6.Width = Button6.Width - 5;
			Button7.Width = Button7.Width - 5;
			Button8.Width = Button8.Width - 5;
			Button9.Width = Button9.Width - 5;
			Button10.Width = Button10.Width - 5;
			Button11.Width = Button11.Width - 5;
			Button12.Width = Button12.Width - 5;

			Button1.Height = Button1.Height - 5;
			Button2.Height = Button2.Height - 5;
			Button3.Height = Button3.Height - 5;
			Button4.Height = Button4.Height - 5;
			Button5.Height = Button5.Height - 5;
			Button6.Height = Button6.Height - 5;
			Button7.Height = Button7.Height - 5;
			Button8.Height = Button8.Height - 5;
			Button9.Height = Button9.Height - 5;
			Button10.Height = Button10.Height - 5;
			Button11.Height = Button11.Height - 5;
			Button12.Height = Button12.Height - 5;
		}

		private void Button2_Click(object sender, RoutedEventArgs e)
		{
			Button1.Width = Button1.Width + 5;
			Button2.Width = Button2.Width + 5;
			Button3.Width = Button3.Width + 5;
			Button4.Width = Button4.Width + 5;
			Button5.Width = Button5.Width + 5;
			Button6.Width = Button6.Width + 5;
			Button7.Width = Button7.Width + 5;
			Button8.Width = Button8.Width + 5;
			Button9.Width = Button9.Width + 5;
			Button10.Width = Button10.Width + 5;
			Button11.Width = Button11.Width + 5;
			Button12.Width = Button12.Width + 5;

			Button1.Height = Button1.Height + 5;
			Button2.Height = Button2.Height + 5;
			Button3.Height = Button3.Height + 5;
			Button4.Height = Button4.Height + 5;
			Button5.Height = Button5.Height + 5;
			Button6.Height = Button6.Height + 5;
			Button7.Height = Button7.Height + 5;
			Button8.Height = Button8.Height + 5;
			Button9.Height = Button9.Height + 5;
			Button10.Height = Button10.Height + 5;
			Button11.Height = Button11.Height + 5;
			Button12.Height = Button12.Height + 5;
		}
	}
}