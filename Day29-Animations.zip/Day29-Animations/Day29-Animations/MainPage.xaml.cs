﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace Day29_Animations
{
	public partial class MainPage : PhoneApplicationPage
	{
		// Constructor
		public MainPage()
		{
			InitializeComponent();
			rectangle1.MouseLeftButtonDown +=new MouseButtonEventHandler(rectangle1_MouseLeftButtonDown);
			DoorOpen.Completed += new EventHandler(DoorOpen_Completed);
		}

		void DoorOpen_Completed(object sender, EventArgs e)
		{
			NavigationService.Navigate(new Uri("/Page2.xaml", UriKind.Relative));
		}

		private void rectangle1_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			DoorOpen.Begin();
		}
	}
}