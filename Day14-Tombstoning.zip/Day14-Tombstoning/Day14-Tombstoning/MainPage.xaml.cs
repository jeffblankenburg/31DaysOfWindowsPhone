﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using System.Windows.Threading;

namespace Day14_Tombstoning
{
	public partial class MainPage : PhoneApplicationPage
	{
		DispatcherTimer timer;
		int secondsSinceStart;
		
		// Constructor
		public MainPage()
		{
			InitializeComponent();

			timer = new DispatcherTimer();
			timer.Interval = TimeSpan.FromSeconds(1);
			timer.Tick += new EventHandler(timer_Tick);
		}

		void timer_Tick(object sender, EventArgs e)
		{
			secondsSinceStart++;
			writeTime();
		}

		private void writeTime()
		{
			TimerTextBlock.Text = TimeSpan.FromSeconds(secondsSinceStart).ToString();
		}

		protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
		{
			base.OnNavigatedTo(e);
			if (PhoneApplicationService.Current.State.ContainsKey("LeftTime"))
			{
				TempText.Text = (string)PhoneApplicationService.Current.State["TextValue"];
				DateTime deactivated = (DateTime)PhoneApplicationService.Current.State["LeftTime"];
				secondsSinceStart = (int)(DateTime.Now - deactivated).TotalSeconds + (int)PhoneApplicationService.Current.State["ElapsedTime"];
				writeTime();
				writeDate();
				timer.Start();
			}
			else secondsSinceStart = 0;
		}

		protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
		{
			base.OnNavigatedFrom(e);
			timer.Stop();
			PhoneApplicationService.Current.State["ElapsedTime"] = secondsSinceStart;
			PhoneApplicationService.Current.State["TextValue"] = TempText.Text;
		}

		private void StartButton_Click(object sender, RoutedEventArgs e)
		{
			writeTime();
			secondsSinceStart = 0;
			writeDate();
			timer.Start();
		}

		private void writeDate()
		{
			DateSinceText.Text = "Timer running since " + (DateTime.Now.AddSeconds(-secondsSinceStart));
		}
	}
}