﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;

namespace Day7_Launchers
{
	public partial class MainPage : PhoneApplicationPage
	{
		// Constructor
		public MainPage()
		{
			InitializeComponent();
		}

		private void EmailButton_Click(object sender, RoutedEventArgs e)
		{
			EmailComposeTask ect = new EmailComposeTask();
			ect.To = "launchers@jeffblankenburg.com";
			ect.Body = "This is one NICE body.";
			ect.Cc = "launcherscopy@jeffblankenburg.com";
			ect.Subject = "This is the subject we should have studied.";
			ect.Show();
		}

		private void MarketplaceDetailButton_Click(object sender, RoutedEventArgs e)
		{
			MarketplaceDetailTask mdt = new MarketplaceDetailTask();
			mdt.ContentType = MarketplaceContentType.Applications;
			mdt.Show();
		}

		private void MarketplaceHubButton_Click(object sender, RoutedEventArgs e)
		{
			MarketplaceHubTask mht = new MarketplaceHubTask();
			mht.ContentType = MarketplaceContentType.Applications;
			mht.Show();
		}

		private void MarketplaceReviewButton_Click(object sender, RoutedEventArgs e)
		{
			MarketplaceReviewTask mrt = new MarketplaceReviewTask();
			mrt.Show();

		}

		private void MarketplaceSearchButton_Click(object sender, RoutedEventArgs e)
		{
			MarketplaceSearchTask marketplaceSearchTask = new MarketplaceSearchTask();
			marketplaceSearchTask.ContentType = MarketplaceContentType.Music;
			marketplaceSearchTask.SearchTerms = "yellow ledbetter";
			marketplaceSearchTask.Show();
		}

		private void MediaPlayerButton_Click(object sender, RoutedEventArgs e)
		{
			MediaPlayerLauncher mpl = new MediaPlayerLauncher();
			mpl.Media = new Uri("TacoBellCanon.mp3", UriKind.Relative);
			mpl.Location = MediaLocationType.Install;
			mpl.Controls = MediaPlaybackControls.Pause | MediaPlaybackControls.Stop;
			mpl.Show();

		}

		private void PhoneCallButton_Click(object sender, RoutedEventArgs e)
		{
			PhoneCallTask pct = new PhoneCallTask();
			pct.PhoneNumber = "2018086011";
			pct.DisplayName = "Jeff Blankenburg";
			pct.Show();

		}

		private void WebBrowserButton_Click(object sender, RoutedEventArgs e)
		{
			WebBrowserTask wbt = new WebBrowserTask();
			wbt.URL = "http://blankensoft.com";
			wbt.Show();

		}

		private void SearchTaskButton_Click(object sender, RoutedEventArgs e)
		{
			SearchTask st = new SearchTask();
			st.SearchQuery = "jeff blankenburg";
			st.Show();

		}

		private void SMSButton_Click(object sender, RoutedEventArgs e)
		{
			SmsComposeTask sct = new SmsComposeTask();
			sct.To = "5555555555";
			sct.Body = "Call me when you have a chance.  Let's do lunch today.";
			sct.Show();
		}

		private void SaveEmailButton_Click(object sender, RoutedEventArgs e)
		{
			SaveEmailAddressTask seat = new SaveEmailAddressTask();
			seat.Email = "jeblank@microsoft.com";
			seat.Show();
		}

		private void SavePhoneButton_Click(object sender, RoutedEventArgs e)
		{
			SavePhoneNumberTask spnt = new SavePhoneNumberTask();
			spnt.PhoneNumber = "5555555555";
			spnt.Show();
		}
	}
}