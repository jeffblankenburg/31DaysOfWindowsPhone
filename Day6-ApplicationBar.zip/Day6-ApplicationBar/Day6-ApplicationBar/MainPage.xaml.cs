﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace Day6_ApplicationBar
{
	public partial class MainPage : PhoneApplicationPage
	{
		// Constructor
		public MainPage()
		{
			InitializeComponent();
		}

		private void AddButton_Click(object sender, EventArgs e)
		{
			Counter.Text = (Int32.Parse(Counter.Text.ToString()) + 1).ToString(); 
		}

		private void SubtractButton_Click(object sender, EventArgs e)
		{
			Counter.Text = (Int32.Parse(Counter.Text.ToString()) - 1).ToString(); 
		}

		private void Shrink_Click(object sender, EventArgs e)
		{
			Counter.FontSize = Counter.FontSize - 20;
		}

		private void Grow_Click(object sender, EventArgs e)
		{
			Counter.FontSize = Counter.FontSize + 20;
		}
	}
}